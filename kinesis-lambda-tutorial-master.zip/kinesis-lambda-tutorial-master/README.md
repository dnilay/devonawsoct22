# kinesis-lambda-tutorial
 sample project for kinesis lambda integration
