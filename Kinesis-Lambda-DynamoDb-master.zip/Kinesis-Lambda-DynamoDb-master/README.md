# Kinesis-Lambda-DynamoDb
Java implementation of Lambda that reads data from Kinesis and saves to DynamoDb
